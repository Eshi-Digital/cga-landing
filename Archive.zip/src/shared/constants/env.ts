export const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;
export const NODE_ENV = process.env.NODE_ENV;
